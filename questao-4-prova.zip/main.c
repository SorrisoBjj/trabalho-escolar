/* Este programa faz o seguinte:

Solicita ao usuário um valor de troco válido (maior ou igual a 0).
Inicializa um contador de moedas.
Define os valores das moedas em centavos (25, 10, 5 e 1).
Calcula o número mínimo de moedas necessárias para dar o troco.
Imprime o número de moedas.
Certifique-se de ter a biblioteca cs50 instalada para usar a função get_int */

#include <stdio.h>

int main(void)
{
    int moeda;

    // Solicita ao usuário um valor de troco válido
    do
    {
        printf("Troco para o cliente: ");
        scanf("%d", &moeda);
    }
    while (moeda <= 0);

    // Inicializa o contador de moedas
    int cont = 0;

    // Define os valores das moedas em centavos
    int valores_Moedas[] = {25, 10, 5, 1};

    // Calcula o número mínimo de moedas
    for (int i = 0; i < 4; i++)
    {
        while (moeda >= valores_Moedas[i])
        {
            moeda -= valores_Moedas[i];
            cont++;
        }
    }

    // Imprime o número de moedas
    printf("%d\n", cont);

    return 0;
}