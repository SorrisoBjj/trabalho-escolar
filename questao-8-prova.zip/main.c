#include <stdio.h>
#include <math.h>

int main() {
    int a, b, c;
    int i=0;
    
    while (i<3) {
        // Leitura dos valores
        scanf("%d %d %d", &a, &b, &c);
        
        // Verifica o caso de término
        if (a == 0 && b == 0 && c == 0) {
            break;
        }
        
        // Calcula a área da casa
        int A_casa = a * b;
        
        // Calcula a área mínima do terreno necessário
        double A_terreno = (double)(A_casa * 100) / c;
        
        // Calcula o lado do terreno necessário
        double lado_terreno = sqrt(A_terreno);
        
        // Trunca o valor para baixo
        int lado_Terr_trunc = (int)lado_terreno;
        
        // Imprime o resultado
        printf("%d\n", lado_Terr_trunc);
    }
    
    return 0;
}